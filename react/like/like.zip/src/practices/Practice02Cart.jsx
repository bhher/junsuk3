import React, { useState } from 'react'

const products = [
  { id: 1, name: '노트북', price: 1200000, quantity: 1 },
  { id: 2, name: '마우스', price: 30000, quantity: 1 },
  { id: 3, name: '키보드', price: 80000, quantity: 1 },
];

function Practice02Cart() {
   const [cart, setCart] = useState(products);
  return (
   <div className='panel'>
      <h2>장바구니</h2>   
      {cart.map((item) => ( 
        <div key={item.id}>
          <span>{item.price}원 </span>
          <strong>{item.name} </strong>
          <span>수량: {item.quantity}개</span>    
        </div>
      ))}   
    </div>
  )
}

export default Practice02Cart