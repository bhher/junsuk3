import Practice01Like from "./practices/Practice01Like"
import Practice02Cart from "./practices/Practice02Cart"


function App() {
  return (
    <div>
      <Practice01Like/>
      <Practice02Cart/>
    </div>
  )
}

export default App